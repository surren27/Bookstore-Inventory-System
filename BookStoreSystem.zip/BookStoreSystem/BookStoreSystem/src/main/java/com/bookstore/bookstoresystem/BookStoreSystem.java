/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.bookstore.bookstoresystem;
import SalesModule.LoginGUI;

/**
 *
 * @author user
 */
public class BookStoreSystem {

    public static void main(String[] args) {
       LoginGUI login = new LoginGUI();
        login.setVisible(true);
    }
}
